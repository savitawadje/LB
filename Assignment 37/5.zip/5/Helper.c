#include "Header.h"

BOOL ChkPalindrome(char *Str)
{
    BOOL bRet = TRUE;
    
    if(Str == NULL) {
        return -1;
    }
    
    char *first,*last;
    first =  Str;
    last = Str;
 
     
    while(*last != '\0'){
    	last++;
    }
  	last--;
 
 
  	
  	while(first <=last){
  		if (((*first) >= 'A') && ((*first) <= 'Z')){
  			if(((*first)==(*last)) || ((*first)==(*last+32))){
  				first++;
  				last--;
  			}
  		}
  		else if (((*first) >= 'a') && ((*first) <= 'z')){
  			if(((*first)==(*last) || (*first)==(*last-32))){
  				first++;
  				last--;
  			}
  		}
  		else{
  			bRet = FALSE;  			
  			break;
  		}
  		
  	}
 }
